import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SearchDetailsService {
  getCountryUrl:any;
  constructor(private httpClient: HttpClient) { }

  getCountryNames(value:string):Observable<any>{
   return this.httpClient.get<any>("https://api.nationalize.io/?name="+value);
  }

  getAllCounties(CountryCode:any):Observable<any>{
    if(CountryCode.length >1){
      this.getCountryUrl = "https://restcountries.eu/rest/v2/alpha?codes="+CountryCode[0]['country_id']+';'+CountryCode[1]['country_id'];
    }else{
      this.getCountryUrl = "https://restcountries.eu/rest/v2/alpha?codes="+CountryCode[0]['country_id'];
    }
    return this.httpClient.get<any>(this.getCountryUrl);
  }
}
