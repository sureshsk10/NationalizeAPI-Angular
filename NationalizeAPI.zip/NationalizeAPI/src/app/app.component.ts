import { Component, OnInit } from '@angular/core';
import { debounce } from 'typescript-debounce-decorator';
import { SearchDetailsService } from './search-details.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'nationalizeAPI';
  name:any;
  tableView:boolean =false;
  serachResult:any;
  countryNames:any;
  constructor(private myServices: SearchDetailsService) { }
  ngOnInit(){

  }

  @debounce(500)
  searchCountry(value:string){
    if(value != ''){
      this.tableView = true;
    }else{
      this.tableView = false;
    }
    this.myServices.getCountryNames(value).subscribe((data)=> {
      this.serachResult = data.country.slice(0, 2);
      this.myServices.getAllCounties(this.serachResult).subscribe((countryName:string)=>{
        this.countryNames = countryName;
        console.log(countryName,'names');
      });
    });
  }
}
